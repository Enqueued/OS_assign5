#include "geninc.h"

struct PCB init_PCB(){
  struct PCB new;
  new.cpu = 0;
  new.priority = 0;
  new.io = 0;
}

pthread_t create_thread(){
}

pthread_t wait_thread(){
}

pthread_t kill_thread(){
}


